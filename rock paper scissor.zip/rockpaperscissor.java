import java.util.Scanner;
import swing.JOptionPane;

public class RockPaperScissors {
    private enum Move {
	Rock, Paper, Scissors
    }
    
   public static void main(String[] args) { 
    

    public int compareMoves(Move othermove) {
            // Tie 
            if (this == otherMove)
 		return 0;

	    switch (this) {
	    case ROCK :
		return (otherMove == SCISSORS ? 1 : -1);
            case PAPER 
		return (otherMove == ROCK ? 1 : -1);
	    case SCISSORS :
	  	return (otherMove == PAPER ? 1: -1);
	    }
	    // Should never reach here
            return 0;
            
            if (user.playAgain()) {
	        JOptionPane.showInputDialog();
	        startGame();
            } else {
                printGameStats();
            }     


    public void startGame() {
        System.out.print( "Rock, Paper, or Scissors? ")
Move userMove = user. getMove();
Move computerMove = computer.getMove(null, userMove);
jOptionPane.showMessageDialog(null, (userMove))

System.out.println("Computer played " + computerMove + "/n");


    }
    private class User {
	private Scanner inputScanner;

	public User () {
	    inputScanner = jOptionPane.showInputDialog("enter your name")
    }
    public class Computer {
        public Move getMove() {
            Move[] moves = Move.values();
            Random random = new Random();
            int index = random.nextInt(moves.length);
            return moves[index];
 	
        String userInput = inputScanner next.line();
        userInput = userInput.toUpperCase();
	char firstLetter = userInput.chartAt(0);
        if (firstLetter == 'R' || firstLetter == 'P' || firstLetter == 'S') {
            // User enters a valid input
            switch (firstLetter) {
            case 'R': 
                return Move.Rock;
            case 'P':
		return Move.Paper;
	    case 'S':
		return Move.Scissors;
	    }
	// User has not entered a valid input
	return get.Move();
	}
}
int compareMoves = userMove.compareMoves(computerMove);
switch (compareMoves) {
case 0: // Tie
   JOptionPane("Tie!");
   break;
case 1: // User wins
   JOptionPane(userMove + " beats " + computerMove + ". You won!");
   userScore++;
   break;
}
numberOfGames++;

    public boolean playAgain() {
	JOptionPane("Do you want to play again? ");
	String userInput = inputScanner.nextLine();
	userInput = userInput.toUpperCase ();
	return userInput.chartAt(0) == 'Y'; 
   
        public RockPaperScissors() {

private User user;
private Computer comuter;
private int userScore;
private int computerScore;
private int numberOfGames;

public RockPaperScissors(){
    user - new User();
    computer = new Computer();
    userScore = 0
    computerScore = 0;
    numberOfGames = 0;
    
    }

  

   


